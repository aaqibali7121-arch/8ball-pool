# 8 Ball Live Assistant — APK-build-ready Android project

## Build requirements
- Android Studio Ladybug or newer
- Android SDK 35
- JDK 17
- Internet access for the first Gradle dependency download

## Build APK
Open this folder in Android Studio, allow Gradle sync, then:
Build > Build APK(s)

Debug APK will normally be generated under:
app/build/outputs/apk/debug/app-debug.apk

## Phone permissions
The app requests:
1. Display over other apps — required for the transparent guide.
2. Screen capture — required for live frame analysis.

## Current scope
This project is a live-screen analysis foundation. It does not automatically drag the cue, press controls, or execute a shot.

## Solver work still required
The capture callback is intentionally separated from the solver. Add the computer-vision pipeline there:
- table/pocket detection
- ball detection/tracking
- target selection
- ghost-ball geometry
- bank/cushion geometry
- power estimation
- spin recommendation
- confidence/risk

The overlay should only display the resulting guide.
