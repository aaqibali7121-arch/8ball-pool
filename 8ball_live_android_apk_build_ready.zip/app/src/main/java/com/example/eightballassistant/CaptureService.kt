package com.example.eightballassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import kotlin.math.*

class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: GuideOverlay? = null
    private var windowManager: WindowManager? = null

    override fun onCreate() {
        super.onCreate()

        val channel = NotificationChannel(
            "live_analysis",
            "Live Analysis",
            NotificationManager.IMPORTANCE_LOW
        )

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)

        startForeground(
            100,
            Notification.Builder(this, "live_analysis")
                .setContentTitle("8 Ball Live Assistant")
                .setContentText("Live screen analysis is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        )
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        val resultCode =
            intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
                ?: return START_NOT_STICKY

        val data =
            intent.getParcelableExtra<Intent>("captureData")
                ?: return START_NOT_STICKY

        setupOverlay()
        setupCapture(resultCode, data)

        return START_STICKY
    }

    private fun setupOverlay() {
        val metrics = resources.displayMetrics

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        overlay = GuideOverlay(this)

        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        windowManager?.addView(overlay, params)
    }

    private fun setupCapture(
        resultCode: Int,
        data: Intent
    ) {
        val metrics = resources.displayMetrics

        val manager =
            getSystemService(MEDIA_PROJECTION_SERVICE)
                    as MediaProjectionManager

        projection = manager.getMediaProjection(resultCode, data)

        reader = ImageReader.newInstance(
            metrics.widthPixels,
            metrics.heightPixels,
            PixelFormat.RGBA_8888,
            2
        )

        display = projection?.createVirtualDisplay(
            "EightBallLiveCapture",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface,
            null,
            null
        )

        reader?.setOnImageAvailableListener(
            { imageReader ->

                val image = imageReader.acquireLatestImage()
                    ?: return@setOnImageAvailableListener

                try {
                    /*
                     * SOLVER PIPELINE PLACEHOLDER
                     *
                     * Next implementation:
                     * 1. Convert frame to bitmap.
                     * 2. Locate green table boundary.
                     * 3. Detect six pockets.
                     * 4. Detect cue/target balls.
                     * 5. Calculate ghost-ball contact point.
                     * 6. Score legal pockets.
                     * 7. Estimate angle/power/spin.
                     * 8. Send guide geometry to GuideOverlay.
                     *
                     * No game controls are touched.
                     */

                    overlay?.postInvalidate()

                } finally {
                    image.close()
                }

            },
            Handler(Looper.getMainLooper())
        )
    }

    override fun onDestroy() {

        reader?.close()
        display?.release()
        projection?.stop()

        overlay?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private class GuideOverlay(
        context: Context
    ) : View(context) {

        private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(70, 235, 175)
            strokeWidth = 5f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(
                floatArrayOf(18f, 12f),
                0f
            )
        }

        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            /*
             * Demo geometry only.
             * Replace these coordinates with the CV solver output.
             */
            val w = width.toFloat()
            val h = height.toFloat()

            canvas.drawLine(
                w * 0.60f,
                h * 0.50f,
                w * 0.80f,
                h * 0.50f,
                guidePaint
            )

            canvas.drawText(
                "LIVE GUIDE",
                30f,
                70f,
                textPaint
            )
        }
    }
}
