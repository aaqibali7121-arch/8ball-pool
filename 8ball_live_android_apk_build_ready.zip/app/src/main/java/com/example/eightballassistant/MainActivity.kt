package com.example.eightballassistant

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    private val captureRequest = 701
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)

        findViewById<Button>(R.id.startButton).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Status: Please allow 'Display over other apps'"
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                return@setOnClickListener
            }

            val manager =
                getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

            status.text = "Status: Requesting screen capture permission…"
            startActivityForResult(
                manager.createScreenCaptureIntent(),
                captureRequest
            )
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "Status: Stopped"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != captureRequest ||
            resultCode != RESULT_OK ||
            data == null
        ) {
            status.text = "Status: Screen capture cancelled"
            return
        }

        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            putExtra("resultCode", resultCode)
            putExtra("captureData", data)
        }

        startForegroundService(serviceIntent)
        status.text = "Status: Live analysis started"
    }
}
